# disabledSubtypes

disable subtypes for fields

## Usage

```javascript
var options = {
  disabledSubtypes: {
    text: ['password'],
  },
}
$(container).formBuilder(options)
```

## See it in Action

<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="zmBWZa" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
