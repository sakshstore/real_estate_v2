<?php

namespace App\Http\Controllers;

use App\Models\Property;
use Illuminate\Http\Request;

use Jackiedo\DotenvEditor\Facades\DotenvEditor;
/**
 * Class PropertyController
 * @package App\Http\Controllers
 */
class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
     
     
         $user=Auth::user();
 
$user_id=$user->id;


       
        
        
     
        $properties = Property::where("user_id",$user_id)->orderBy("id","desc")->paginate();
        
      return view('property.index', compact('properties'))
            ->with('i', (request()->input('page', 1) - 1) * $properties->perPage());
    
        
        
        
    }
    
    
    
    
    public function section_settings()
    {
        
  $logo_sliders_images=DotenvEditor::getValue('LOGO_SLIDERS_IMAGE') ;
        
  $logo_images= explode(',',  $logo_sliders_images); 
        
        
        
  $carousel_images=DotenvEditor::getValue('CAROUSEL_IMAGES') ;
  
     $carousel_images= explode(',',  $carousel_images); 
    
 
 
 
 
 
        return view('sections.set_sections_image', compact('logo_images','carousel_images'));
        
 
    }
    
    
    public function post_logo_slider_images(Request $request)
    {
        
  
         $file = $request->file('file');
         
         
      $imagefileName  = time().'__'.$file->getClientOriginalName();
      
      $gallery=array();
      
   $logo_slider = $file->storeAs('logo_slider', $imagefileName, 'public');
        
        
   //     if(!$this->validate_gallery_image(  $file))         abort(401);;
        
          $logo_sliders_images=DotenvEditor::getValue('LOGO_SLIDERS_IMAGE') ;
        
  $logo_sliders_images_ar= explode(',',  $logo_sliders_images); 
        
        
         
          
      
          $logo_sliders_images_ar[]=$logo_slider;
          
          
          
 $logo_sliders_images_str=implode(',',  $logo_sliders_images_ar);    
 
 

           $editor = DotenvEditor::setKeys([
    
    'LOGO_SLIDERS_IMAGE' =>$logo_sliders_images_str  
    
    
]);


$editor->save();

return "Uploaded succesfully";

  

    }
    
    
    public function post_carousel_images(Request $request)
    {
        
  
         $file = $request->file('file');
         
         
      $imagefileName  = time().'__'.$file->getClientOriginalName();
      
   
      
   $carousel_slider = $file->storeAs('carousel_slider', $imagefileName, 'public');
        
        
        $carousel_sliders_images=DotenvEditor::getValue('CAROUSEL_IMAGES') ;
        
  $carousel_sliders_images_ar= explode(',',  $carousel_sliders_images); 
        
        
   $carousel_sliders_images_ar[]=$carousel_slider;
          
          
          
 $carousel_sliders_images_str=implode(',',  $carousel_sliders_images_ar);    
 
  
    echo $carousel_sliders_images_str;

           $editor = DotenvEditor::setKeys([
    
    'CAROUSEL_IMAGES' =>$carousel_sliders_images_str  
    
    
]);


$editor->save();

return "Uploaded succesfully";

  

    }
    

public function remove_carousel_image(Request $request ){
    
        $carousel_sliders_images=DotenvEditor::getValue('CAROUSEL_IMAGES') ;
        
        
  $carousel_sliders_images_array= explode("," ,$carousel_sliders_images);
  
  $carousel_sliders_images_new_ar=array();
  
  
 
  foreach($carousel_sliders_images_array as $image)
  {
     
      if( asset(   $image ) ==  $request->name    )
      {
        
         
          
      }
      else
      {
          
          
          
        
           
      array_push($carousel_sliders_images_new_ar,$image);
      }
  }
  
  
  
  
  $carousel_sliders_images_new_str= implode("," ,$carousel_sliders_images_new_ar);
  
  
  
  
     $editor = DotenvEditor::setKeys([
    
    'CAROUSEL_IMAGES' =>$carousel_sliders_images_new_str  
    
    
]);


$editor->save();
 
  return  "Removed";
    
    
    
}



public function remove_logo_sliders_image(Request $request ){
    
        $logo_sliders_images=DotenvEditor::getValue('LOGO_SLIDERS_IMAGE') ;
        
        
  $logo_sliders_images_array= explode("," ,$logo_sliders_images);
  
  $logo_sliders_images_new_ar=array();
  
  
 
  foreach($logo_sliders_images_array as $image)
  {
     
      if( asset(   $image ) ==  $request->name    )
      {
        
         
          
      }
      else
      {
          
          
          
        
           
      array_push($logo_sliders_images_new_ar,$image);
      }
  }
  
  $logo_sliders_images_new_str= implode("," ,$logo_sliders_images_new_ar);
  
  
     $editor = DotenvEditor::setKeys([
    
    'LOGO_SLIDERS_IMAGE' =>$logo_sliders_images_new_str  
    
    
]);


$editor->save();
 
  return  "Removed";
    
    
    
}




    public function propertyarchive(Request $request)
    {
        
       

        $properties = Property::where("status","Published")->paginate();

        return view('property.property_archive', compact('properties'))
            ->with('i', (request()->input('page', 1) - 1) * $properties->perPage());
    }  
    
    
    public function query_property($query)
    {
        
      
         if($query=="all")
         
        $properties = Property::paginate();
        
        else
        
        
       $properties= Property::where('tags', 'like', '%' . $query . '%')->where("status","Published")->paginate();
    

    

        return view('property.property_archive', compact('properties'))
            ->with('i', (request()->input('page', 1) - 1) * $properties->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $property = new Property();
        
        
        $property = Property::latest()->first();
        
        
        //return view('property.create', compact('property'));
        
        
        $case="new";
        
        $connectivity_array=get_connectivity_tags(); 

$amminities_array=get_amminities_tags(); 

 
        return view('property.edit_property', compact('property','connectivity_array','amminities_array','case'));
        
        
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
      //  return $request->floor_details;
       // request()->validate(Property::$rules);
       
        $property=new Property();
       
       $property->project_name=$request->project_name;
       $property->starting_price=$request->starting_price;
       $property->tenure=$request->tenure;
       $property->property_type=$request->property_type;
       $property->size_from=$request->size_from;
       $property->completion=$request->completion;
       $property->interiors=$request->interiors;
       $property->payment_plan_short=$request->payment_plan_short;
       $property->payment_plan_details=$request->payment_plan_details;
       $property->down_payment=$request->down_payment;
       $property->connectivity=$request->connectivity;
       $property->unit_details=$request->unit_details;
       $property->floor_details=$request->floor_details;
       $property->amenities=$request->amenities;
       $property->location=$request->location;
       $property->address=$request->address;
       $property->location_gps=$request->location_gps;
       $property->bedrooms=$request->bedrooms;
       $property->project_details=$request->project_details;
       
       
       
       $property->developer=$request->developer;
       $property->broker_id=$request->broker_id;
       $property->latitude=$request->latitude;
       $property->longitude=$request->longitude;
       
       
        $aminities=array();
  $aminities_array=json_decode($request->aminities);
 foreach ($aminities_array as $aminities_element) {
 	array_push($aminities,$aminities_element->value);
}

 $aminities_list=implode(",",$aminities);



       $property->aminities=$aminities_list;
       
    
    $property->save();
    
      

 return redirect()->route('properties.index')
          ->with('success', 'Property created successfully.');
    }
    public function duplicate_property(Property $property)
    
    {
        $new_property = $property->replicate();
        
        $new_property->save();
         
         
          
    return redirect()->route('properties.edit_property', [$new_property]);
    }

  public function publish_property(Property $property)
    
    {
        $property->status="Published";
        
        $property->save();
         
         
          return redirect()->route('properties.index')
          ->with('success', 'Property updated successfully.');
    }
  public function unpublish_property(Property $property)
    
    {
       $property->status="Unpublished";
        
        $property->save();
         
         
          return redirect()->route('properties.index')
          ->with('success', 'Property updated successfully.');
    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $property = Property::find($id);

        return view('property.show', compact('property'));
    }


public function set_property_image(Property $property){
    
    
 return view('property.set_property_image', compact('property'));
    
    
}





public function remove_brochure_url(Request $request,Property $property){
    
  $property->brochure_url= "";
    
  
   $property->save();
   
   return "Removed!!!";
    
}




public function remove_feature_image_from_gallery(Request $request,Property $property){
    
   
  $property->property_thumbnail_url= "";
  
   $property->save();
   
   return "Removed!!!";
    
}






public function remove_image_from_gallery(Request $request,Property $property){
    
  $original_gallery_url= json_decode( $property->gallery_url);
  
  $new_gallery_url=array();
  
  
 
  foreach($original_gallery_url as $image)
  {
     
      if( asset(   $image ) ==  $request->name    )
      {
        
         
          
      }
      else
      {
          
          
          
        
           
      array_push($new_gallery_url,$image);
      }
  }
  
  
  $property->gallery_url=json_encode($new_gallery_url);
  
   $property->save();
    
   
  return  "Removed";
    
    
    
}



      public function post_set_property_images(Request $request,Property $property){
    
   
         $file = $request->file('file');
         
         
      $imagefileName  = time().'__'.$file->getClientOriginalName();
      
      $gallery=array();
   $property_gallery_url = $file->storeAs('property_gallery', $imagefileName, 'public');
        
        
        if(!$this->validate_gallery_image(  $file))         abort(401);;
        
        
        
          $gallery=json_decode(  $property->gallery_url );
          
      
          $gallery[]=$property_gallery_url;
          
          
          
 $property->gallery_url= json_encode( $gallery);
 
 if(is_null($property->property_thumbnail_url))
 $property->property_thumbnail_url= $property_gallery_url;
 
 
 
 
 $property->save();
 
 
return "Uploaded succesfully";



 
}
  public function post_brochure(Request $request,Property $property){
    
   
         $file = $request->file('file');
         
         
      $imagefileName  = time().'__'.$file->getClientOriginalName();
      
       
   $property_brochure_url = $file->storeAs('property_brochure', $imagefileName, 'public');
        
      
 $property->brochure_url= $property_brochure_url;
 
 $property->save();
 
 
return "Uploaded succesfully";



 
}


      public function post_set_thumbnail_image(Request $request,Property $property){
    
   
         $file = $request->file('file');
         
         
      $imagefileName  = time().'__'.$file->getClientOriginalName();
      
       
   $property_thumbnail_url = $file->storeAs('property_thumbnail', $imagefileName, 'public');
        
      
 $property->property_thumbnail_url= $property_thumbnail_url;
 
 $property->save();
 
 
return "Uploaded succesfully";



 
}



public function remove_connectivity(Request $request,Property $property){
    
    
 
    
    
  $connectivities= json_decode( $property->connectivities);
  
  $new_connectivities=array();
  
  
 
  foreach($connectivities  as $element)
  {
     echo  $element->name  ;
        echo $request->connectivity_name;
     
      if( $request->connectivity_name ==  $element->name    )
      {
        
         
          
      }
      else
      {
          
          
          
        
           
      array_push($new_connectivities,$element);
      }
  }
  
  
  $property->connectivities=json_encode($new_connectivities);
  
   $property->save();
    
   
  return   $property->connectivities. "Removed";
    
    
    
}



public function update_connectivity(Request $request,Property $property){
    
    
    $connectivity=array();
    
    
    
         $connectivity['name']=get_value_array_from_tag(   $request->connectivity_name)[0];
         
         $connectivity['distance']= $request->connectivity_distance;
         
          
       
      
         $connectivities=json_decode(  $property->connectivities );
          
      
          $connectivities[]=$connectivity;
          
          
          
 $property->connectivities= json_encode( $connectivities);
 
    $property->save();
    
    
  return redirect()->back( )
          ->with('success', 'Property updated successfully.');
}


public function update_video(Request $request,Property $property){
    
    
    
          
          
 $property->video_url= $request->video_url;
 
    $property->save();
    
    
return "connectivity updated succesfully";
}


public function viewProperty(Property $property){
    
    
 return view('property.view_property', compact('property'));
    
    
}
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    
    
    public function edit($id)
    {
        $property = Property::find($id);
        
$connectivity_array=get_connectivity_tags(); 

$amminities_array=get_amminities_tags(); 
$case="edit";
 
        return view('property.edit_property', compact('property','connectivity_array','amminities_array','case'));
    }
    
    

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Property $property
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Property $property)
    {
        request()->validate(Property::$rules);

        $property->update($request->all());


    if(isset($request->aminities))
    
    {
        $aminities=array();
  $aminities_array=json_decode($request->aminities);
 foreach ($aminities_array as $aminities_element) {
 	array_push($aminities,$aminities_element->value);
}

 $aminities_list=implode(",",$aminities);



       $property->aminities=$aminities_list;
       
        $property->save();
       
    }  
        return redirect()->route('properties.index')
            ->with('success', 'Property updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $property = Property::find($id)->delete();

        return redirect()->route('properties.index')
            ->with('success', 'Property deleted successfully');
    }
    
    public function validate_gallery_image($image)
    { 
  
 
list($width, $height, $type, $attr) = getimagesize($image);



   if($width < 600)
   return false;
   else
   return true;
   
   
    }
}
