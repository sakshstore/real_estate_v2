@extends('layouts.app-master')
@section('template_title')
    {{ __('Update') }} Property
@endsection

@section('content')


					<div class="col-md-8">
					    
					   


                        {{ __('Update') }} Property 
                   
                        
                        
					    
   <nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
      
      
      
    <button class="nav-link active" id="nav-overview-tab" data-bs-toggle="tab" data-bs-target="#nav-overview" type="button" role="tab" aria-controls="nav-overview" aria-selected="true">overview</button>
    
    
    
    
    <button class="nav-link" id="nav-floorplan-tab" data-bs-toggle="tab" data-bs-target="#nav-floorplan" type="button" role="tab" aria-controls="nav-floorplan" aria-selected="false">floorplan</button>
    
    
    <button class="nav-link" id="nav-amenities-tab" data-bs-toggle="tab" data-bs-target="#nav-amenities" type="button" role="tab" aria-controls="nav-amenities" aria-selected="false">amenities</button>
    
    
    <button class="nav-link" id="nav-connectivities-tab" data-bs-toggle="tab" data-bs-target="#nav-connectivities" type="button" role="tab" aria-controls="nav-connectivities" aria-selected="false">connectivities</button>
    
    
    <button class="nav-link" id="nav-set_property_image-tab" data-bs-toggle="tab" data-bs-target="#nav-set_property_image" type="button" role="tab" aria-controls="nav-set_property_image" aria-selected="false">set_property_image</button>
    
    
    <button class="nav-link" id="nav-masterplan-tab" data-bs-toggle="tab" data-bs-target="#nav-masterplan" type="button" role="tab" aria-controls="nav-masterplan" aria-selected="false">masterplan</button>
    
    
    <button class="nav-link" id="nav-paymentplan-tab" data-bs-toggle="tab" data-bs-target="#nav-paymentplan" type="button" role="tab" aria-controls="nav-paymentplan" aria-selected="false">paymentplan</button>
    
    
    
    
    
    
    
    
    
    
    <button class="nav-link" id="nav-setvideo-tab" data-bs-toggle="tab" data-bs-target="#nav-setvideo" type="button" role="tab" aria-controls="nav-contact" aria-selected="false">setvideo</button>
    
     
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-overview" role="tabpanel" aria-labelledby="nav-overview-tab" tabindex="0">.   @include('property.edit_sections.overview')..</div>
  
  
  
  <div class="tab-pane fade" id="nav-floorplan" role="tabpanel" aria-labelledby="nav-floorplan-tab" tabindex="0">.. @include('property.edit_sections.floor_details')  .</div>
  
  
  <div class="tab-pane fade" id="nav-amenities" role="tabpanel" aria-labelledby="nav-amenities-tab" tabindex="0">.  @include('property.edit_sections.aminities') ..</div>
  
  
  <div class="tab-pane fade" id="nav-connectivities" role="tabpanel" aria-labelledby="nav-connectivities-tab" tabindex="0">@include('property.edit_sections.set_connectivity')</div>
  
  
  <div class="tab-pane fade" id="nav-set_property_image" role="tabpanel" aria-labelledby="nav-set_property_image-tab" tabindex="0">@include('property.edit_sections.set_property_image')</div>
  
  
  <div class="tab-pane fade" id="nav-masterplan" role="masterplan" aria-labelledby="nav-masterplan-tab" tabindex="0">..@include('property.edit_sections.project_details') .</div>
  
  
  <div class="tab-pane fade" id="nav-paymentplan" role="tabpanel" aria-labelledby="nav-paymentplan-tab" tabindex="0"> @include('property.edit_sections.payment_plan_details') </div>
  
  
  <div class="tab-pane fade" id="nav-setvideo" role="tabpanel" aria-labelledby="nav-setvideo-tab" tabindex="0">@include('property.edit_sections.set_video')</div>
   
  
   
</div>

</div>


 

   	 
                    
@endsection

@section('style')       
                    
               <link href="https://unpkg.com/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />
                         
                    
@endsection

@section('scripts')

   
<script src="https://unpkg.com/@yaireo/tagify"></script>
  <script src="https://unpkg.com/@yaireo/tagify@3.1.0/dist/tagify.polyfills.min.js"></script>
 
 
    
                        
                        <script src="https://cdn.ckeditor.com/ckeditor5/38.1.0/classic/ckeditor.js"></script>
                        
                        
                          <script>
                            
  var input = document.querySelector('.tags');
 
  
  

 



   var  tags_values= ["Children's Playground","Swimming Pool" ,"24-hr Security","Barbecue Area","Yoga Area","Sports Court","Sauna Room","EV Station","Organic Green Houses", "Daycare Center","Elite Family Seating","Open Air Cinema","Elite Business Center","Elite Cafe","Prayer Hall","Kids Play Zone","Kids Splash Pad","BBQ Area","Cigar Lounge","Rain Shower","Recreational Zone","Library","Cabana Seating","Multi-Purpose Hall","Cricket Pitch","Mini Golf","Table Tennis","Chess Board","Mini Basketball","Water Feature","Smart Mart","Swimming Pool","Kids Swimming Pool","SPA & Therapy","Jacuzzi","Lazy Lounge","Jogging Track","Beauty Salon","Doctor On Call","Open air Yoga platform","Health Club","Health Bar","Indoor & Outdoor Gym","Aquatic Gym","Trampoline Area","Wall Climbing","Dance Studio","Snooker Zone","Badminton Court"];


  
  

 
    // init Tagify script on the above inputs
    tagify = new Tagify(input, {
      whitelist: tags_values,
      
      dropdown: {
               
        classname: "tags-look",  
        enabled: 0,             // <- show suggestions on focus
        closeOnSelect: false    // <- do not hide the suggestions dropdown once an item has been selected
      }
    })
    
    
    
    
    
 var allEditors = document.querySelectorAll('.editor');
                           
                           
        for (var i = 0; i < allEditors.length; ++i) {
          ClassicEditor.create(allEditors[i]);
        }
        
         
                </script> 
@endsection