# sortableControls
`sortableControls` Allows user's to reorder the controls to their liking. Positions are saved to `window.sessionStorage`.

## Usage
```javascript
var options = {
      sortableControls: true // defaults to false
    };
$(container).formBuilder(options);
```

## See it in Action
<p data-height="494" data-theme-id="22927" data-slug-hash="eZErvG" data-default-tab="result" data-user="kevinchappell" data-embed-version="2" class="codepen"></a>.</p>
